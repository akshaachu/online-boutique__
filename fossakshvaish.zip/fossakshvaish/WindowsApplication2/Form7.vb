﻿Public Class Form7
    Dim Num1 As Integer
    Dim Num2 As Integer
    Dim Ans1 As Integer
    Dim Num3 As Integer
    Dim Num4 As Integer
    Dim Ans2 As Integer

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Form4.Show()
        Me.Hide()

    End Sub

    Private Sub Form7_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ColdDataSet.cld' table. You can move, or remove it, as needed.
        Me.CldTableAdapter.Fill(Me.ColdDataSet.cld)
        'TODO: This line of code loads data into the 'HotDataSet.ht' table. You can move, or remove it, as needed.
        Me.HtTableAdapter.Fill(Me.HotDataSet.ht)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Num1 = TextBox1.Text
        Num2 = TextBox2.Text
        
        Ans1 = Num1 * Num2
        Ans2 = Num3 * Num4
        TextBox3.Text = Ans1

        
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Num3 = TextBox4.Text
        Num4 = TextBox5.Text
        Ans2 = Num3 * Num4
        TextBox6.Text = Ans2

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click

    End Sub
End Class